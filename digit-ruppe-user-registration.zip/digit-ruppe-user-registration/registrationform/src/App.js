import './App.css';
import RegistrationForm from './RegistrationForm';

function App() {
  return (
    <div className="App">
       <h1>RegistrationForm</h1>
      <RegistrationForm/>
    </div>
  );
}

export default App;
